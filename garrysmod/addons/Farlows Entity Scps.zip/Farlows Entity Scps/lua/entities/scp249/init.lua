AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

--========================================================--
--   GLOBAL COOLDOWN (5 SECONDS)
--========================================================--
local GLOBAL_COOLDOWN = 5
ENT.NextUse = 0

--========================================================--
--   INITIALIZATION
--========================================================--
function ENT:Initialize()
    self:SetModel("models/props_c17/door03_left.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    self:SetUseType(SIMPLE_USE)
end

--========================================================--
--   DESTINATION TABLES (UPDATED)
--========================================================--

local NormalDestinations = {
    Vector(2539.561768, 1734.230957, 64.031250),
    Vector(390.127441, -303.874725, -63.968750),
}

local RareDestinations = {
    Vector(2539.561768, 1734.230957, 64.031250),
    Vector(390.127441, -303.874725, -63.968750),
}

local UltraRareDestinations = {
    Vector(2539.561768, 1734.230957, 64.031250),
    Vector(390.127441, -303.874725, -63.968750),
}

--========================================================--
--   DESTINATION SELECTION
--========================================================--
local function ChooseDestination()
    local roll = math.random(1, 10000)

    if roll <= 10 then
        return table.Random(UltraRareDestinations), "ULTRA_RARE"
    end

    if roll <= 210 then
        return table.Random(RareDestinations), "RARE"
    end

    return table.Random(NormalDestinations), "NORMAL"
end

--========================================================--
--   USE INTERACTION + COOLDOWN + SOUND
--========================================================--
function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    -- GLOBAL COOLDOWN CHECK
    if CurTime() < self.NextUse then
        local wait = math.Round(self.NextUse - CurTime(), 1)
        activator:ChatPrint("[SCP-249] The door resists... (" .. wait .. "s)")
        return
    end

    -- Set next allowed use
    self.NextUse = CurTime() + GLOBAL_COOLDOWN

    -- Play door movement sound
    self:EmitSound("doors/door1_move.wav", 75, 100)

    -- Choose teleport destination
    local dest, rarity = ChooseDestination()

    -- Feedback
    if rarity == "RARE" then
        activator:ChatPrint("[SCP-249] The door hums strangely...")
    elseif rarity == "ULTRA_RARE" then
        activator:ChatPrint("[SCP-249] Reality bends as the door opens...")
    end

    -- Teleport player
    activator:SetPos(dest)
    activator:ScreenFade(SCREENFADE.IN, Color(0,0,0,255), 0.5, 0.5)
end